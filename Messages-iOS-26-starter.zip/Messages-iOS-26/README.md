# Messages iOS 26

A SwiftUI starter project for an iPhone-style messaging interface.

## Included
- Conversation list with search
- New conversation sheet
- Chat screen with message bubbles
- Local demo messages and sending
- Reusable contact avatars

## Important
This is a starter UI, not a complete online messaging service. Messages are stored only in app memory and reset when the app restarts. Firebase Authentication, Firestore, Storage, push notifications, photo attachments, and voice messages still need to be configured.

## Open in Xcode
1. On a Mac with a compatible version of Xcode, create a new iOS **App** project named `Messages`.
2. Choose **SwiftUI** for the interface and **Swift** for the language.
3. Remove the generated Swift files from the project if needed.
4. Add all `.swift` files from the `Messages` folder to the Xcode project. Ensure **Copy items if needed** is selected and the app target is checked.
5. Build and run on an iPhone simulator.

## Repository
Suggested repository name: `Messages-iOS-26`
